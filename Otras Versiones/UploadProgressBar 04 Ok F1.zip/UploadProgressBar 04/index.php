<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="">
<meta name="author" content="">

<link rel="icon" href="favicon.ico">

<title>Progress bar jquery php</title>

<!-- Bootstrap core CSS -->
<link href="css/bootstrap.min.css" rel="stylesheet">
<!-- Custom styles for this template -->
<link href="css/sticky-footer-navbar.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="css/style.css">
<!--
<script src="https://code.jquery.com/jquery-3.3.1.min.js" type="text/javascript"></script>
-->

    <!-- Only for jquery -->

<script src='js/jquery-3.4.1' type="text/javascript"></script>
<script src='js/jquery-3.4.1.min.js' type="text/javascript"></script>

<script type="text/javascript" src="js/jquery.form.min.js"></script>

<script type="text/javascript">

$(document).ready(function () {
    $('#submitButton').click(function () {
    	$('#uploadForm').ajaxForm({
    	    target: '#salidaImagen',
    	    url: 'CargarArchivos.php',
    	    beforeSubmit: function () {
    	        $("#salidaImagen").hide();
    	        if($("#uploadImage").val() == "") {
    	        	$("#salidaImagen").show();
    	        	$("#salidaImagen").html("<div class='error'>SELECCIONE UN ARCHIVO PARA SUBIR</div>");
                    return false; 
				}
				
				// INICIO VALIDACION EXTENSION ARCHIVO
				if($("#uploadImage").val() != "") {
					ext_ok = new Array(".gif", ".jpg", ".png", ".jpeg", ".mkv", ".mp4", ".avi", ".webm");

					var archivo = $("#uploadImage").val();

				    //recupero la extensión de este nombre de archivo
				    ext = (archivo.substring(archivo.lastIndexOf("."))).toLowerCase();
				    //compruebo si la extensión está entre las permitidas
				    permitida = "";
				    for (var i = 0; i < ext_ok.length; i++) {
				       if (ext_ok[i] == ext) {
				       permitida = "yes";
				       break;
					         }else {permitida = "no";}
						} // FIN for

					if(permitida == "yes"){/*return true;*/}
					if(permitida == "no"){
						$("#salidaImagen").show();
						$("#salidaImagen").html("<div class='error'>TIPO DE ARCHIVO NO PERMITIDO</div>");
						return false;}
					}
					// FIN VALIDACION TIPO DE EXTENSION
					
    	            $("#progressDivId").css("display", "block");
    	            var percentValue = '0%';
    	            $('#progressBar').width(percentValue);
					$('#percent').html(percentValue);
					
    	        }, // FIN beforeSubmit
    	        uploadProgress: function (event, position, total, percentComplete) {

    	            var percentValue = percentComplete + '%';
    	            $("#progressBar").animate({
    	                width: '' + percentValue + ''
    	            }, {
    	                //duration: 5000,
    	                duration: 300, // 300 microsegundos = 3 centesimas de segundo
    	                easing: "linear",
    	                step: function (x) {
                        percentText = Math.round(x * 100 / percentComplete);
    	                    /*$("#percent").text(percentText + "%");*/
                          $("#percent").text("");
                        if(percentText == "100") {
                        	   $("#salidaImagen").show();
                        }
    	                }
    	            });
    	        },
    	        error: function (response, status, e) {
    	            alert('Oops something went.');
    	        },
    	        /* */
    	        complete: function (xhr) {
    	            if (xhr.responseText && xhr.responseText != "error")
    	            {
    	            	  //$("#salidaImagen").html(xhr.responseText);
    	            }
    	            else{  
    	               	//$("#salidaImagen").show();
        	            $("#salidaImagen").html("<div class='error'>Problema al cargar el archivo.</div>");
        	            //$("#progressBar").stop();
    	            }
              }

    	    });

    }); // FIN #submitButton.click
});
</script>

</head>

<body>

<!-- Begin page content -->

<div class="container">

  <h5 class="mt-5">Subir imagen con progress bar usando jquery php</h5>
  <hr>

  <div class="row">
    <div class="col-12 col-md-12"> 

<!-- Contenido -->

<div class="form-container"> 

  <form class="form-inline" action="CargarArchivos.php" id="uploadForm" name="frmupload" method="post" enctype="multipart/form-data">

    <div class="form-group mx-sm-3 mb-2">
	  <input type="file" id="uploadImage" name="uploadImage" />
    </div>

    <button id="submitButton" type="submit" class="btn btn-primary mb-2" name='btnSubmit'>
      CARGAR IMAGEN / VIDEO
    </button>
	  <button type="reset" class="btn btn-primary mb-2">BORRAR FORMULARIO</button>

  </form>

  <!-- -->

    <div class='progress' id="progressDivId">
        <div class='progress-bar' id='progressBar'></div>
        <div class='percent' id='percent'>0%</div>
    </div>
<!--   
    <div style="height: 10px;"></div>
-->
    <div id='salidaImagen'></div>


 </div>
 
 <!-- Fin Form-container -->  

      <!-- Fin Contenido --> 

    </div>
  </div>

  <!-- Fin row --> 
  
</div>
<!-- Fin container -->

<!-- 
          Bootstrap core JavaScript
    ================================================== 
--> 

<!-- Placed at the end of the document so the pages load faster --> 
<script src="js/bootstrap.min.js"></script>


</body>
</html>